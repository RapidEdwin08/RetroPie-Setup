#!/bin/bash
# https://github.com/RapidEdwin08

# No PS2 Emulator cacheDIR
ps2EMU=???
cacheDIR='NO PS2 Cache Found!'

# https://github.com/RapidEdwin08/RetroPie-Setup/blob/master/ext/RetroPie-Extra/scriptmodules/emulators/aethersx2.sh
if [ -d ~/.config/aethersx2/cache ]; then cacheDIR=~/.config/aethersx2/cache; ps2EMU=AetherSX2; fi

# https://github.com/Exarkuniv/RetroPie-Extra/blob/master/scriptmodules/emulators/aethersx2.sh
if [ -d /opt/retropie/configs/ps2/Config/cache ]; then cacheDIR=/opt/retropie/configs/ps2/Config/cache; ps2EMU=AetherSX2; fi

# PCSX2
if [ -d ~/.config/PCSX2/cache ]; then cacheDIR=~/.config/PCSX2/cache; ps2EMU=PCSX2; fi

# Custom cacheDIR ps2EMU
##cacheDIR=
##ps2EMU=

 bootLOGO=$(
echo '


           ##############         #######  ###############  
                        #         #                      #  
           ##############         #        ###############  
           #                      #        ##               
           #               ########        ################ 
                                                                             

  # vulkan_pipelines.bin # vulkan_shaders.bin # vulkan_shaders.idx #
')

mainMENU()
{

# Menu Clean
ps2CACHE=$(dialog --no-collapse --title "   CURRENT $ps2EMU Cache: [$cacheDIR]   " \
	--ok-label OK --cancel-label EXIT \
	--menu "                    #  $ps2EMU Cache Cleaner  # $bootLOGO" 25 75 20 \
	1 "VIEW  $ps2EMU Cache " \
	2 "CLEAN $ps2EMU Vulkan Cache " \
	3 "INSTALL $ps2EMU Cache Cleaner to [runcommand-menu]" \
	X "EXIT" 2>&1>/dev/tty)
	
if [ ! "$ps2CACHE" == '' ]; then
	# View PS2 Cache
	if [ "$ps2CACHE" == '1' ]; then
		if [ "$cacheDIR" == 'NO $ps2EMU Cache Found!' ]; then
			dialog --no-collapse --title "   $cacheDIR   " --ok-label Back --msgbox "*NO $ps2EMU Cache Found in either of these Locations:\n$HOME/.config/aethersx2/cache \n/opt/retropie/configs/ps2/Config/cache "  25 75
			mainMENU
		fi
		dialog --no-collapse --title "   CURRENT $ps2EMU Cache: [$cacheDIR]   " --ok-label Back --msgbox "$(ls -l --block-size=MB $cacheDIR | awk '{print $5,$9}')"  25 75
		mainMENU
	fi
	# Clean PS2 Cache
	if [ "$ps2CACHE" == '2' ]; then
		if [ "$cacheDIR" == 'NO $ps2EMU Cache Found!' ]; then
			dialog --no-collapse --title "   $cacheDIR   " --ok-label Back --msgbox "*NO $ps2EMU Cache Found in either of these Locations:\n$HOME/.config/aethersx2/cache \n/opt/retropie/configs/ps2/Config/cache "  25 75
			mainMENU
		fi
		confCLEANps2=$(dialog --no-collapse --title "   CURRENT $ps2EMU Cache: [$cacheDIR]   " \
		--ok-label OK --cancel-label BACK \
		--menu "                          ? ARE YOU SURE ?                            \n DELETE: vulkan_pipelines.bin vulkan_shaders.bin vulkan_shaders.idx" 25 75 20 \
		Y " YES CLEAN $ps2EMU Vulkan Cache " \
		N " NO" 2>&1>/dev/tty)
		if [ "$confCLEANps2" == 'Y' ] && [ ! "$cacheDIR" == 'NO $ps2EMU Cache Found!' ]; then
			rm $cacheDIR/vulkan_pipelines.bin > /dev/null 2>&1
			rm $cacheDIR/vulkan_shaders.bin > /dev/null 2>&1
			rm $cacheDIR/vulkan_shaders.idx > /dev/null 2>&1
			#rm $cacheDIR/gamelist.cache > /dev/null 2>&1
			dialog --no-collapse --title "   CLEAN [$cacheDIR] COMPLETE   " --ok-label Back --msgbox "$(ls -l --block-size=MB $cacheDIR | awk '{print $5,$9}')"  25 75
		fi
	fi
	# INSTALL PS2 Cache Cleaner to [runcommand-menu] 
	if [ "$ps2CACHE" == '3' ]; then
		if [ "$0" == '/opt/retropie/configs/all/runcommand-menu/CacheSX2Cleaner.sh' ]; then
			dialog --no-collapse --title "   ALREADY INSTALLED!   " --ok-label Back --msgbox " *You are RUNNING $ps2EMU Cache Cleaner from [runcommand-menu] NOW* $(ls /opt/retropie/configs/all/runcommand-menu)"  25 75
			mainMENU
		fi
		confRUNcmd=$(dialog --no-collapse --title "   INSTALL $ps2EMU Cache Cleaner to [runcommand-menu]   " \
		--ok-label OK --cancel-label BACK \
		--menu "                          ? ARE YOU SURE ?                            \n /opt/retropie/configs/all/runcommand-menu/CacheSX2Cleaner.sh" 25 75 20 \
		1 " INSTALL $ps2EMU Cache Cleaner  to  [runcommand-menu] " \
		2 " REMOVE  $ps2EMU Cache Cleaner from [runcommand-menu] " \
		B " BACK" 2>&1>/dev/tty)
		if [ "$confRUNcmd" == '1' ]; then
			cp "$0" /dev/shm/CacheSX2Cleaner.sh
			if [[ ! -d /opt/retropie/configs/all/runcommand-menu ]]; then mkdir /opt/retropie/configs/all/runcommand-menu; fi
			mv /dev/shm/CacheSX2Cleaner.sh /opt/retropie/configs/all/runcommand-menu/CacheSX2Cleaner.sh
			chmod 755 /opt/retropie/configs/all/runcommand-menu/CacheSX2Cleaner.sh
			dialog --no-collapse --title "   INSTALL $ps2EMU Cache Cleaner to [runcommand-menu] COMPLETE   " --ok-label Back --msgbox "$(ls /opt/retropie/configs/all/runcommand-menu)"  25 75
		fi
		if [ "$confRUNcmd" == '2' ]; then
			rm /opt/retropie/configs/all/runcommand-menu/CacheSX2Cleaner.sh
			dialog --no-collapse --title "   REMOVE $ps2EMU Cache Cleaner from [runcommand-menu] COMPLETE   " --ok-label Back --msgbox "$(ls /opt/retropie/configs/all/runcommand-menu)"  25 75
		fi
	fi
	# EXIT
	if [ "$ps2CACHE" == 'X' ]; then
		tput reset
		exit 0
	fi
fi

if [ "$ps2CACHE" == '' ]; then tput reset; exit 0; fi

mainMENU
}


mainMENU

tput reset
exit 0
