#!/bin/bash

app_img=pcsx2-linux-appimage-x64-Qt.AppImage
app_dir=/opt/retropie/emulators/pcsx2-x64
pushd $app_dir

# Start Emulator
if [[ "$1" == '' ]] || [[ "$1" == *"+Start PCSX2"* ]]; then
	$app_dir/$app_img -bigpicture -fullscreen
elif [[ "$1" == *"--editor"* ]]; then
	$app_dir/$app_img -fullscreen
else
	if [ "$(ls ~/RetroPie/BIOS/SCPH*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/scph*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/ps2*)" == '' ]; then #DisplayMissingBIOS
		#sudo fbi -T 2 -a -noverbose $app_dir/PS2BIOSRequired.jpg > /dev/null 2>&1; sleep 7; sudo kill $(pgrep fbi) > /dev/null 2>&1; popd; exit 0
		echo "***N0TICE***  PS2 BIOS NOT FOUND! You Need to Install PS2 BIOS [~/RetroPie/BIOS/SCPH-XXXXX.nvm] 1st!" # /dev/shm/runcommand.log is just fine...
	fi
        if [[ "$1" == *"uLaunchELF"* ]] && [[ $(cat /home/pi/.config/pcsx2/inis/PCSX2.ini | grep -q 'EnableFastBoot = false' ; echo $?) == '1' ]]; then sed -i 's+EnableFastBoot\ =.*+EnableFastBoot\ =\ false+g' /home/pi/.config/pcsx2/inis/PCSX2.ini; fi
        if [[ ! "$1" == *"uLaunchELF"* ]] && [[ $(cat /home/pi/.config/pcsx2/inis/PCSX2.ini | grep -q 'EnableFastBoot = true' ; echo $?) == '1' ]]; then sed -i 's+EnableFastBoot\ =.*+EnableFastBoot\ =\ true+g' /home/pi/.config/pcsx2/inis/PCSX2.ini; fi
        $app_dir/$app_img -bigpicture -fullscreen "$@"
fi
popd
