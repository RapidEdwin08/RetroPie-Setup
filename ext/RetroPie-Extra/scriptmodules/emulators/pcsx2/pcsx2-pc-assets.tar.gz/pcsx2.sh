#!/bin/bash

# Use [matchbox-window-manager -use_titlebar no &] for Fullscreen
if [[ "$1" == '' ]]; then
	matchbox-window-manager -use_titlebar no & /opt/retropie/emulators/pcsx2/pcsx2-v2.0.2-linux-appimage-x64-Qt.AppImage -bigpicture -fullscreen
else
	if [ "$(ls ~/RetroPie/BIOS/SCPH*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/scph*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/ps2*)" == '' ]; then #DisplayMissingBIOS
		sudo fbi -T 2 -a -noverbose /opt/retropie/emulators/pcsx2/PS2BIOSRequired.jpg > /dev/null 2>&1; sleep 7; sudo kill $(pgrep fbi) > /dev/null 2>&1; exit 0
	fi
        if [[ "$1" == *"uLaunchELF"* ]] && [[ $(cat /home/pi/.config/pcsx2/inis/PCSX2.ini | grep -q 'EnableFastBoot = false' ; echo $?) == '1' ]]; then sed -i 's+EnableFastBoot\ =.*+EnableFastBoot\ =\ false+g' /home/pi/.config/pcsx2/inis/PCSX2.ini; fi
        if [[ ! "$1" == *"uLaunchELF"* ]] && [[ $(cat /home/pi/.config/pcsx2/inis/PCSX2.ini | grep -q 'EnableFastBoot = true' ; echo $?) == '1' ]]; then sed -i 's+EnableFastBoot\ =.*+EnableFastBoot\ =\ true+g' /home/pi/.config/pcsx2/inis/PCSX2.ini; fi
        matchbox-window-manager -use_titlebar no & /opt/retropie/emulators/pcsx2/pcsx2-v2.0.2-linux-appimage-x64-Qt.AppImage -bigpicture -fullscreen "$1"
fi
