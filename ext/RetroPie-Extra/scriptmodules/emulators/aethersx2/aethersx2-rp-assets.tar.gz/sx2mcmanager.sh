#!/bin/bash
# https://github.com/RapidEdwin08

# ACTIVATE MemoryCard Manager by APPENDING '(mc)' or '(MC)' to ANY PS2-ROM-NAME.iso

# Example: uLaunchELF 4.42d.iso --> uLaunchELF 4.42d (MC).iso
# RESULT MemoryCard Setting PCSX2.ini: Slot1_Filename = uLaunchELF 4.42d (MC).ps2

# RUNS with [onstart] or [onend] to Manage Individual MemoryCards for PS2 (MC)s
# UPDATES [PCSX2.ini] MemoryCard Slot1_Filename to 'PS2-ROM-(MC)-NAME.ps2' on [runcommand-onstart]
# RETURNS [PCSX2.ini] MemoryCard Slot1_Filename to 'Mcd001.ps2' on [runcommand-onend]

# INSTALL to [/opt/retropie/configs/ps2/mcmanager.sh] and make executable
##chmod 755 /opt/retropie/configs/ps2/mcmanager.sh

# ADD to [runcommand-onstart.sh] to SET Individual MemoryCard - Slot1_Filename = PS2-ROM-(MC)-NAME.ps2
##if [[ "$1" == "ps2" ]]; then bash /opt/retropie/configs/ps2/mcmanager.sh onstart; fi #For Use With [mcmanager]

# ADD to [runcommand-onend.sh] to RESTORE Default MC - Slot1_Filename = Mcd001.ps2
##if [ "$(head -1 /dev/shm/runcommand.info)" == "ps2" ]; then bash /opt/retropie/configs/ps2/mcmanager.sh onend; fi #For Use With [mcmanager]

romNAME="$(basename "$(head -3 /dev/shm/runcommand.info | tail +3)" )"
mcNAME="${romNAME%.*}.ps2"
runCMDlog=/dev/shm/runcommand.log
sx2INI=~/.config/aethersx2/inis/PCSX2.ini
if [[ -f ~/.config/PCSX2/inis/PCSX2.ini ]]; then sx2INI=~/.config/PCSX2/inis/PCSX2.ini; fi
if [[ -f /opt/retropie/configs/ps2/Config/inis/PCSX2.ini ]]; then sx2INI=/opt/retropie/configs/ps2/Config/inis/PCSX2.ini; fi
if [[ ! -f "$sx2INI.b4mcmanager" ]]; then cp "$sx2INI" "$sx2INI.b4mcmanager"; fi # Backup PCSX2.ini

# Restore Slot1 to Default Mcd001.ps2 if ROM NOT (MC) + PCSX2.ini Slot1 Setting IS *(MC)* - In case runcommand-onend did not Restore from Power Off
if [[ ! "$romNAME" == *"(mc)"* ]] && [[ ! "$romNAME" == *"(MC)"* ]]; then
	if [[ ! "$(cat $sx2INI | grep ^Slot1_Filename | grep \(mc\))" == '' ]] || [[ ! "$(cat $sx2INI | grep ^Slot1_Filename | grep \(MC\))" == '' ]]; then
		echo [mcmanager] LOADED PS2 ROM withOUT \(mc\) or \(MC\): $romNAME >> $runCMDlog
		echo [mcmanager] CHECK [$sx2INI]: $(cat $sx2INI | grep ^Slot1_Filename) >> $runCMDlog
		echo [mcmanager] RESTORE Default PS2 MemoryCard Name: Mcd001.ps2 >> $runCMDlog
		# Slot1_Filename = Mcd001.ps2
		sed -i "s/^Slot1_Filename\ =.*/Slot1_Filename\ =\ Mcd001.ps2/g" $sx2INI
	fi
	exit 0 # Do Nothing if ROM NOT (MC) and Slot1 Setting in PCSX2.ini NOT (MC)
fi

# onstart: Set Individual PS2 MemoryCard if (MC)
if [ "$1" == "onstart" ]; then
	echo [mcmanager] LOADED PS2 ROM with \(mc\) or \(MC\): $romNAME >> $runCMDlog
	echo [mcmanager] UPDATE PS2 MemoryCard Name: $mcNAME >> $runCMDlog
	# Slot1_Filename = $romNAME.ps2
	sed -i "s/^Slot1_Filename\ =.*/Slot1_Filename\ =\ $mcNAME/g" $sx2INI
fi

# onend: Restore Default PS2 MemoryCard if (MC)
if [ "$1" == "onend" ]; then
	echo [mcmanager] FINISHED PS2 ROM with \(mc\) or \(MC\): $romNAME >> $runCMDlog
	echo [mcmanager] RESTORE PS2 Default MemoryCard Name: Mcd001.ps2 >> $runCMDlog
	# Slot1_Filename = Mcd001.ps2
	sed -i "s/^Slot1_Filename\ =.*/Slot1_Filename\ =\ Mcd001.ps2/g" $sx2INI
fi

echo [mcmanager] CHECK [$sx2INI]: $(cat $sx2INI | grep ^Slot1_Filename) >> $runCMDlog
