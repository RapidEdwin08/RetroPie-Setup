#!/bin/bash
emu_AppImage=DuckStation-x64.AppImage

pushd /opt/retropie/configs/psx/duckstation/

# Use [matchbox-window-manager -use_titlebar no &] for Fullscreen
if [[ "$1" == '' ]] || [[ "$1" == *"+Start DuckStation"* ]]; then
	matchbox-window-manager -use_titlebar no & /opt/retropie/emulators/duckstation/$emu_AppImage -bigpicture -fullscreen
elif [[ "$1" == *"--editor"* ]]; then
	matchbox-window-manager -use_titlebar no & /opt/retropie/emulators/duckstation/$emu_AppImage -fullscreen
else
	if [ "$(ls ~/RetroPie/BIOS/SCPH*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/scph*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/psx*)" == '' ]; then #DisplayMissingBIOS
		sudo fbi -T 2 -a -noverbose /opt/retropie/emulators/duckstation/PSXBIOSRequired.jpg > /dev/null 2>&1; sleep 7; sudo kill $(pgrep fbi) > /dev/null 2>&1; exit 0
	fi
        matchbox-window-manager -use_titlebar no & /opt/retropie/emulators/duckstation/$emu_AppImage -bigpicture -fullscreen "$1"
fi

popd
