Chronic - by - MasterPlan inc. and Fullerene Productions Inc.

More information and Screen shots.  WWW.BADMEAT.COM - WWW.FULLERENE.COM

================================================================
Title                   : Chronic
Date                    : 05/23/2000 
Filename                : chronic.pk3
Author                  : MasterPlan
Email Address           : meatpak@hotmail.com
Description             : Deathmatch Level Staring Eminem and Dr.Dre
                         

Additional Credits and thanks to   :  Courtney Holt, Interscope records.

                       
================================================================

- Play Information -

Players                 : 2 to 12.
Bots                    : Yes.
Weapons                 : All
Armor                   : yes
Ammo                    : yes
Health                  : yes


		>>>>>>>>TO PLAY THIS MAP<<<<<<<<


Put the chronic.pk3 file into your baseq3 directory, and type one of the following at 
the console.

"\map chronic"


- Construction -

Base                    : From scratch
Editor(s) used          : Q3Radiant
Additional Tools	: Q3Build. Photoshop
Known Bugs              : None.
Build Time              : 1 month.

Textures used           : Origninal, all textures were created using photoshop.

Compile machine         : P2/450 with 256 MEGS of ram, Gforce, running Windows 2000
q3map BSP Time          : < 1 minutes per level
q3map Vis Time          : 10 minutes
q3map Light Time        : 30 minutes
bspc Time               : 5 minutes

- Other Comments -



- Copyright / Permissions -

These are original maps and textures created by masterplan. You should not include or distribute this map pak in any sort of commercial product.  You may not mass distribute this level pak via any non-electronic means, including but not limited to compact disks, and floppy disks.
